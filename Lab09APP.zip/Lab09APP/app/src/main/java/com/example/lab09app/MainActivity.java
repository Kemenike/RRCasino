/*
Kanayo Emenike
Lab 09
10-22-2020
/// Description-
    This app displays "Hello World!" above a button. When the button is pressed a toast pops up at
        at the bottom of the screen with a developed by message as well as changing the
        "Hello World!" to my name.
 */

package com.example.lab09app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.os.Bundle;
import android.widget.Toast;

import java.util.concurrent.TimeUnit;


public class MainActivity extends AppCompatActivity {

    Button button1;
    TextView text1;
    //Context context = getApplicationContext();
    //CharSequence text = "Developed By: Kanayo Emenike";
    boolean title = true;
    int YS, YF, YD;
    int deviceHeight, deviceWidth;
    int duration = Toast.LENGTH_SHORT;
    //Toast toast = Toast.makeText(context, text, duration);




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        text1 = (TextView)findViewById(R.id.title);
        button1 = (Button)findViewById(R.id.button);
        DisplayMetrics displayMetrics = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        deviceHeight = displayMetrics.heightPixels;
        deviceWidth = displayMetrics.widthPixels;
    }

    public void DisplayName(View v) {
        Context context = getApplicationContext();
        CharSequence text = "Developed By: Kanayo Emenike";
        if(title) {
            text1.setText("Kanayo Emenike");
            Toast.makeText(context, text, duration).show();
            title = false;
        } else {
            text1.setText("Hello World!");
            title = true;
        }
    }

    public boolean onTouchEvent(MotionEvent event) {
        int eventaction = event.getAction();

        switch(eventaction) {
            case MotionEvent.ACTION_DOWN:
                YS = (int) event.getRawY();
            case MotionEvent.ACTION_MOVE:
                YF = (int) event.getRawY();
                YD = YF - YS;
                if(YD > (deviceHeight/2)) {
                    finish();
                    //System.exit(0);
                }
                break;
        }
        return true;
    }
}